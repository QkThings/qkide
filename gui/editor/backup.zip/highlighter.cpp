#include <QtGui>
#include "highlighter.h"

Highlighter::Highlighter(QTextDocument *document) : QSyntaxHighlighter(document)
{
    HighlightingRule rule;

    multiLineCommentFormat.setForeground(Qt::gray);
    //multiLineCommentFormat.setFontWeight(QFont::Bold);

    commentStartExpression = QRegExp("/\\*");
    commentEndExpression = QRegExp("\\*/");
}


QString& Highlighter::getLanguage()
{
    return curLanguage;
}


void Highlighter::setLanguage(const QString &language)
{
    QString keywordColor;
    QString keyword;
    QTextCharFormat keywordFormat;
    //QFile file(":/syntax/" + language);
    QFile file(":/syntax/qk.kw");
    bool stop = false;
    int r,g,b;
    HighlightingRule rule;

    curLanguage = language;

    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        QMessageBox::critical(new QDialog,
                              tr("Error"),
                              tr("Error load syntax higlighter"),
                              QMessageBox::Ok);

        qApp->quit();
    }

    QTextStream input(&file);

    highlightingRules.clear();

    //keywordFormat.setFontWeight(QFont::Bold);

    while (!input.atEnd())
    {
        keywordColor = input.readLine();

        if (keywordColor.contains("#defcolor"))
        {
            r = keywordColor.section(',',1,1).toInt();
            g = keywordColor.section(',',2,2).toInt();
            b = keywordColor.section(',',3,3).toInt();
            keywordFormat.setForeground(QBrush(QColor(r,g,b,255)));
        }

        while (stop == false)
        {
            keyword = input.readLine();

            if (keyword == "stop")
            {
                stop = true;
            }
            else
            {
                rule.format  = keywordFormat;
                rule.pattern = QRegExp(keyword);
                highlightingRules.append(rule);
            }
        }

        stop = false;
    }
}


void Highlighter::highlightBlock(const QString &text)
{
    foreach (const HighlightingRule &rule, highlightingRules)
    {
        QRegExp expression(rule.pattern);
        int index = expression.indexIn(text);

        while (index >= 0)
        {
            int length = expression.matchedLength();
            setFormat(index, length, rule.format);
            index = expression.indexIn(text, index + length);
        }
    }

    setCurrentBlockState(0);

    int startIndex = 0;

    if (previousBlockState() != 1)
    {
        startIndex = commentStartExpression.indexIn(text);
    }

    while (startIndex >= 0)
    {
        int endIndex = commentEndExpression.indexIn(text, startIndex);
        int commentLength;

        if (endIndex == -1)
        {
            setCurrentBlockState(1);
            commentLength = text.length() - startIndex;
        }
        else
        {
            commentLength = endIndex - startIndex
                            + commentEndExpression.matchedLength();
        }

        setFormat(startIndex, commentLength, multiLineCommentFormat);
        startIndex = commentStartExpression.indexIn(text, startIndex + commentLength);
     }
}


void Highlighter::clearHighlightingRule()
{
    highlightingRules.clear();
}
