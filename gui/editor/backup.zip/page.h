#ifndef PAGE_H
#define PAGE_H

#include <QObject>
#include <Qsci/qsciscintilla.h>
#include <Qsci/qsciscintillabase.h>
//#include "highlighter.h"

// ----------------------------------------------------------
// Copied from Scintilla.h
// (Copyright 1998-2003 by Neil Hodgson <neilh@scintilla.org>
// Not included in QScintilla but needed for text search

struct Sci_CharacterRange {
        long cpMin;
        long cpMax;
};
struct Sci_TextToFind {
        struct Sci_CharacterRange chrg;
        char *lpstrText;
        struct Sci_CharacterRange chrgText;
};

#define CharacterRange Sci_CharacterRange
#define TextRange Sci_TextRange
#define TextToFind Sci_TextToFind
// ----------------------------------------------------------

class Highligher;

class Page : public QsciScintilla
{
    Q_OBJECT

public:
    Page(QString name, QWidget *parent = 0);

    QString name() {return m_name;}


public slots:
    void findText(const QString &text);
    void toggleFold();

signals:
    void focused();

protected:
    void focusInEvent(QFocusEvent *e);

private slots:
    void onChar(int charadded);


private:
    Highligher *m_highligher;
    QString m_name;

    bool highlightLine;
    QStringList autoCompletePhrases;

    void setupAutoCompletePhrases();
};


#endif // PAGE_H
