#include "searchdialog.h"
#include "ui_searchdialog.h"

#include "editor.h"

SearchDialog::SearchDialog(Editor *editor, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SearchDialog)
{
    ui->setupUi(this);

    m_editor = editor;
    setWindowFlags(Qt::Tool);
    setWindowTitle(tr("Search"));

    layout()->setSizeConstraint(QLayout::SetFixedSize);

    m_findNextAct = new QAction(this);
    connect(ui->findNext_pushButton, SIGNAL(clicked()), this, SLOT(slotFindNext()));
}

SearchDialog::~SearchDialog()
{
    delete ui;
}

void SearchDialog::slotFindNext()
{
    QString text = ui->find_lineEdit->text();
    m_editor->currentPage()->findText(text);
}

void SearchDialog::slotFindPrev()
{

}

void SearchDialog::slotReplace()
{

}

void SearchDialog::slotReplaceAll()
{

}
