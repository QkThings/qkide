#include <QtGui>
#include <Qsci/qsciscintilla.h>
#include <Qsci/qsciscintillabase.h>
#include <Qsci/qscilexercpp.h>
#include <Qsci/qsciapis.h>

#include <QTextDocument>

#include "page.h"
#include "highlighter.h"

Page::Page(QString name, QWidget *parent) : QsciScintilla(parent)
{
    m_name = name;

    setFrameStyle(QFrame::NoFrame);

    //m_highligher = new Highlighter((QTextDocument*)document());

#ifdef Q_WS_WIN
    QFont defaultFont("Consolas",9);
#else
    QFont defaultFont("Monospace",10);
#endif
    setFont(defaultFont);
    QFontMetrics fm(defaultFont);
    //setLineNumberFont(defaultFont);
    setMarginsFont(defaultFont);

    setMarginWidth(0,fm.width("0000")+5);
    setMarginLineNumbers(0, true);
    setMarginWidth(1,0);

    /*setEdgeMode(QsciScintilla::EdgeLine);
    setEdgeColumn(80);
    setEdgeColor(QColor("#DDDDDD"));*/

    setFolding(QsciScintilla::BoxedTreeFoldStyle);
    setMarginWidth(2,11);


    setBraceMatching(QsciScintilla::SloppyBraceMatch);

    setMarginsBackgroundColor(QColor("#EEEEEE"));
    setMarginsForegroundColor(QColor("#333333"));

    setFoldMarginColors(QColor("#FFFFFF"),QColor("#EFEFEF"));

    setTabWidth(2);
    setAutoIndent(true);

    QsciLexerCPP *lexer = new QsciLexerCPP();
    lexer->setFont(defaultFont);
    lexer->setFoldComments(true);
    setLexer(lexer);

    setupAutoCompletePhrases();

    QsciAPIs *api = new QsciAPIs(lexer);
    foreach(QString phrase , autoCompletePhrases)
    {
        api->add(phrase);
    }
    api->prepare();

    setAutoCompletionThreshold(3);
    //setAutoCompletionSource(QsciScintilla::AcsAll);
    setAutoCompletionSource(QsciScintilla::AcsDocument);

    SendScintilla(SCI_AUTOCSETMAXHEIGHT, 2); // ? not working

    setIndentationGuides(true);
    setIndentationGuidesForegroundColor(QColor(220,220,220));

    connect(this, SIGNAL(SCN_CHARADDED(int)), this, SLOT(onChar(int)));
}

void Page::onChar(int charadded)
{
    /*char c = (char)charadded;
    QString toadd;

    switch(c)
    {
    case '(': toadd.append(")"); break;
    case '"': toadd.append("\""); break;
    default: toadd.append("");
    }

    if(toadd != "")
    {
        SendScintilla(SCI_ADDTEXT, 1, toadd.toLatin1().data());
        int pos = SendScintilla(SCI_GETCURRENTPOS);
        SendScintilla(SCI_GOTOPOS, pos-1);
    }*/
}

void Page::setupAutoCompletePhrases()
{
    autoCompletePhrases.clear();
    autoCompletePhrases.append("spi_set_mode(uint8_t mode)");
}

void Page::findText(const QString &text)
{
    //Sci_CharacterRange chrg;
    //Sci_TextToFind ttf;
    qDebug() << "findText" << text;
    const char *t = text.toUtf8().data();

    int startPos = SendScintilla(SCI_GETCURRENTPOS);
    int endPos = SendScintilla(SCI_GETLINEENDPOSITION, lines());
    SendScintilla(SCI_SETTARGETSTART, startPos);
    SendScintilla(SCI_SETTARGETEND, endPos);

    int pos = SendScintilla(SCI_SEARCHINTARGET, sizeof(t), t);
    if(pos != -1)
    {
        SendScintilla(SCI_GOTOPOS, pos);
        qDebug() << "text found! pos =" << pos;
        SendScintilla(SCI_SETSELECTIONSTART, pos);
        SendScintilla(SCI_SETSELECTIONEND, pos + text.length());
    }

}

void Page::toggleFold()
{
    foldAll();
}

void Page::focusInEvent(QFocusEvent *e)
{
    QsciScintillaBase::focusInEvent(e);

    emit focused();
}

