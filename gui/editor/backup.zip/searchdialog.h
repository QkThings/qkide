#ifndef SEARCHDIALOG_H
#define SEARCHDIALOG_H

#include <QDialog>

class Editor;

namespace Ui {
class SearchDialog;
}

class SearchDialog : public QDialog
{
    Q_OBJECT
    
public:
    explicit SearchDialog(Editor *editor, QWidget *parent = 0);
    ~SearchDialog();
    
private slots:
    void slotFindNext();
    void slotFindPrev();
    void slotReplace();
    void slotReplaceAll();

private:
    Ui::SearchDialog *ui;

    QAction *m_findNextAct;
    QAction *m_findPrevAct;
    QAction *m_replaceAct;
    QAction *m_replaceAllAct;

    Editor *m_editor;
};

#endif // SEARCHDIALOG_H
